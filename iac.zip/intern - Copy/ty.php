<?php


$email = $_POST['email'];
$mobile = $_POST['mobile'];
$Date = $_POST['Date'];
$Event_name = $_POST['Event_name'];


$host = 'localhost' ;
$dbUsername = 'root';
$dbPassword ='';
$dbname= 'pra';

$conn = new mysqli($host , $dbUsername,$dbPassword, $dbname );

if($conn->connect_error) {
die("Connection Failed : $conn->connect_error");
}
else{
$stmt = $conn->prepare("insert into register(email, mobile, Date , Event_name) values( ?, ?, ?, ?)");
$stmt ->bind_param("siss",$email, $mobile, $Date, $Event_name);
$stmt->execute();
$stmt ->close();
$conn->close();
}

<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Gloria+Hallelujah&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Gloria+Hallelujah&family=Ultra&display=swap" rel="stylesheet">
  <style>
      body{
          width:100%;
          height:100%;

      }
      h2{
        font-family: 'Gloria Hallelujah', cursive;
text-align: center;

      }
      printy{
          border-radius: 10px;
          border-color: antiquewhite;
          height: 200px;
          background-color: yellowgreen;
      }
      h1{
      font-family: 'Gloria Hallelujah', cursive;
font-family: 'Ultra', serif;
text-align: center;
      }
      #banner_content{
    position: relative;
    padding-top: 10%;
    padding-bottom: 6%;
    margin-top: 10%;
    margin-bottom: 12%;
    background-color:ghostwhite;
    max-width: 900px;
    border: 1cm;
    box-shadow: antiquewhite;
    border-radius: 5%;

}</style>
    </head>
<body>
    <div class="container">
<div class="row">
    <center>
            <div id="banner_content">
                
            <!--section class="row justify-content-center"--><h1>THANK YOU</h1>
        
                <h2>
            Your Registration has been succesfully done
        </h2>
    
        </section>
    <center>
        <button type="button" class="btn btn-primary"> Print Acknowlegement
            </button>
</center>
</center>
    
        
        </div>
    </div>

</body>
</html>